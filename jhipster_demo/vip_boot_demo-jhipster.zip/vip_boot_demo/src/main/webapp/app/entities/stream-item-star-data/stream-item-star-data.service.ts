import axios from 'axios';

import buildPaginationQueryOpts from '@/shared/sort/sorts';

import { IStreamItemStarData } from '@/shared/model/stream-item-star-data.model';

const baseApiUrl = 'api/stream-item-star-data';

export default class StreamItemStarDataService {
  public find(id: number): Promise<IStreamItemStarData> {
    return new Promise<IStreamItemStarData>((resolve, reject) => {
      axios
        .get(`${baseApiUrl}/${id}`)
        .then(function(res) {
          resolve(res.data);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  public retrieve(paginationQuery?: any): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      axios
        .get(baseApiUrl + `?${buildPaginationQueryOpts(paginationQuery)}`)
        .then(function(res) {
          resolve(res);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  public delete(id: number): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      axios
        .delete(`${baseApiUrl}/${id}`)
        .then(function(res) {
          resolve(res);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  public create(entity: IStreamItemStarData): Promise<IStreamItemStarData> {
    return new Promise<IStreamItemStarData>((resolve, reject) => {
      axios
        .post(`${baseApiUrl}`, entity)
        .then(function(res) {
          resolve(res.data);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  public update(entity: IStreamItemStarData): Promise<IStreamItemStarData> {
    return new Promise<IStreamItemStarData>((resolve, reject) => {
      axios
        .put(`${baseApiUrl}`, entity)
        .then(function(res) {
          resolve(res.data);
        })
        .catch(err => {
          reject(err);
        });
    });
  }
}
