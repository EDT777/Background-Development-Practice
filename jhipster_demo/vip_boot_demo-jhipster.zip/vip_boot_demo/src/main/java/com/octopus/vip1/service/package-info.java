/**
 * Service layer beans.
 */
package com.octopus.vip1.service;
