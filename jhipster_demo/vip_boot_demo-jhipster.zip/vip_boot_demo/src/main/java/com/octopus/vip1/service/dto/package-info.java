/**
 * Data Transfer Objects.
 */
package com.octopus.vip1.service.dto;
