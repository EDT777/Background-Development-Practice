/**
 * Spring Framework configuration files.
 */
package com.octopus.vip1.config;
