/**
 * Spring Data JPA repositories.
 */
package com.octopus.vip1.repository;
