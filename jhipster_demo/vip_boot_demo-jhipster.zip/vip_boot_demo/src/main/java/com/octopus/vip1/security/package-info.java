/**
 * Spring Security configuration.
 */
package com.octopus.vip1.security;
