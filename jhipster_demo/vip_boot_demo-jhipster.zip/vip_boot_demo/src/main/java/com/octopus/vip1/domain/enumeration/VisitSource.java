package com.octopus.vip1.domain.enumeration;

/**
 * The VisitSource enumeration.
 */
public enum VisitSource {
    SEARCH, LIST, PUSH
}
