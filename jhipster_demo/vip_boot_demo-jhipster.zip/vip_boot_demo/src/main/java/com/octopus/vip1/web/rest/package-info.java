/**
 * Spring MVC REST controllers.
 */
package com.octopus.vip1.web.rest;
