/**
 * JPA domain objects.
 */
package com.octopus.vip1.domain;
