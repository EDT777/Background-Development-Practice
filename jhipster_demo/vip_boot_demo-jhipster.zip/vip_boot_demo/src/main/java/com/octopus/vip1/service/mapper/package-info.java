/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.octopus.vip1.service.mapper;
